
import streamlit as st
import joblib
import pandas as pd

from utils.preprocessing import preprocess_text

# -----------------------------
# PAGE CONFIG
# -----------------------------
st.set_page_config(
    page_title="AI Phishing Detector",
    page_icon="🛡️",
    layout="centered"
)

# -----------------------------
# CUSTOM CSS
# -----------------------------
st.markdown("""
<style>

/* Main Background */
.stApp {
    background-color: #050816;
    color: white;
}

/* Main Title */
h1 {
    color: #4FCBFF !important;
    text-align: center;
    font-size: 38px !important;
    font-weight: bold;
    text-shadow: 0px 0px 4px rgba(79, 203, 255, 0.4);
}

/* Subheaders */
h2, h3 {
    color: #00D9FF !important;
}

/* Paragraph Text */
p {
    color: #D6E4FF;
}

/* Text Area */
textarea {
    background-color: #0B1023 !important;
    color: white !important;
    border: 2px solid #00D9FF !important;
    border-radius: 12px !important;
}

/* Buttons */
.stButton>button {
    background-color: transparent;
    color: #00D9FF;
    border: 2px solid #00D9FF;
    border-radius: 12px;
    padding: 12px 25px;
    font-size: 18px;
    font-weight: bold;
    transition: 0.3s;
    box-shadow: 0px 0px 10px #00D9FF;
}

.stButton>button:hover {
    background-color: #00D9FF;
    color: black;
    transform: scale(1.05);
}

/* Sidebar */
section[data-testid="stSidebar"] {
    background-color: #0B1023;
    border-right: 2px solid #00D9FF;
}

/* Success Box */
.stSuccess {
    border: 2px solid #00FF88;
    border-radius: 10px;
}

/* Warning Box */
.stWarning {
    border: 2px solid #FFD700;
    border-radius: 10px;
}

/* Error Box */
.stError {
    border: 2px solid #FF4B4B;
    border-radius: 10px;
}

/* Card Effect */
.block-container {
    padding-top: 2rem;
}

.cyber-box {
    border: 2px solid #00D9FF;
    padding: 20px;
    border-radius: 15px;
    background: rgba(0, 217, 255, 0.05);
    box-shadow: 0px 0px 15px rgba(0, 217, 255, 0.3);
}

</style>
""", unsafe_allow_html=True)

# -----------------------------
# LOAD MODEL
# -----------------------------
model = joblib.load("phishing_model.pkl")
vectorizer = joblib.load("tfidf_vectorizer.pkl")

# -----------------------------
# TITLE
# -----------------------------
st.title("🛡️ AI-Based Real-Time Phishing Detection")

st.markdown("""
<div class="cyber-box">
<h3>🚨 Smart Cybersecurity Protection System</h3>
<p>
This AI-powered system uses Natural Language Processing (NLP) and Machine Learning
to detect phishing, scam, and suspicious messages in real time.
</p>
</div>
""", unsafe_allow_html=True)

# -----------------------------
# SIDEBAR
# -----------------------------
st.sidebar.title("⚡ Detection Pipeline")

st.sidebar.markdown("""
### 🧠 AI Workflow

1. Message Input
2. Text Cleaning
3. Stopword Removal
4. TF-IDF Vectorization
5. ML Classification
6. Threat Prediction

---

### 🔐 Technologies Used
- Python
- Scikit-learn
- NLP
- TF-IDF
- Naive Bayes
- Streamlit

---

### 🎯 Threat Categories
- 🟢 Safe
- 🟡 Suspicious
- 🔴 Phishing
""")

# -----------------------------
# SAMPLE MESSAGES
# -----------------------------
st.subheader("📌 Sample Test Messages")

st.success("Hey bro, are we meeting tomorrow?")

st.warning("Your package delivery is pending. Verify your address.")

st.error("URGENT! Your bank account has been suspended. Verify immediately.")

# -----------------------------
# INPUT BOX
# -----------------------------
st.subheader("✉️ Enter Message")

user_input = st.text_area(
    "",
    height=180,
    placeholder="Paste suspicious SMS, email, or message here..."
)

# -----------------------------
# PREDICTION
# -----------------------------
if st.button("🔍 Analyze Message"):

    if user_input.strip() == "":
        st.warning("⚠️ Please enter a message first.")

    else:

        # Preprocess
        cleaned = preprocess_text(user_input)

        # Vectorize
        vector_input = vectorizer.transform([cleaned])

        # Predict
        prediction = model.predict(vector_input)[0]

        # Probability
        probability = model.predict_proba(vector_input)[0]

        phishing_prob = probability[1] * 100
        safe_prob = probability[0] * 100

        st.subheader("📊 Threat Analysis Result")

        # Result Logic
        if phishing_prob > 50:

            st.error(
                f"🔴 PHISHING DETECTED\n\nThreat Confidence: {phishing_prob:.2f}%"
            )

        elif phishing_prob > 20:

            st.warning(
                f"🟡 SUSPICIOUS MESSAGE\n\nThreat Confidence: {phishing_prob:.2f}%"
            )

        else:

            st.success(
                f"🟢 SAFE MESSAGE\n\nSafety Confidence: {safe_prob:.2f}%"
            )

        # Probability Data
        chart_data = pd.DataFrame({
            'Category': ['Safe', 'Phishing'],
            'Probability': [safe_prob, phishing_prob]
        })

        st.subheader("📈 Detection Probability")

        st.bar_chart(chart_data.set_index('Category'))

        # Suspicious Keyword Detection
        suspicious_keywords = [
            "urgent",
            "verify",
            "click",
            "bank",
            "suspended",
            "reward",
            "blocked",
            "kyc",
            "otp",
            "account"
        ]

        found_keywords = []

        for word in suspicious_keywords:
            if word.lower() in user_input.lower():
                found_keywords.append(word)

        if found_keywords:
            st.subheader("⚠️ Suspicious Keywords Found")

            for keyword in found_keywords:
                st.markdown(f"- 🔹 {keyword}")

# -----------------------------
# FOOTER
# -----------------------------
st.markdown("---")

st.markdown(
    "<center>⚡ Developed for Cybersecurity & AI Hackathons ⚡</center>",
    unsafe_allow_html=True
)
