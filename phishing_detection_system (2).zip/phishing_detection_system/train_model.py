import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report
)

import matplotlib.pyplot as plt
import seaborn as sns

from utils.preprocessing import preprocess_text

# -----------------------------------
# LOAD ORIGINAL DATASET
# -----------------------------------

df = pd.read_csv(
    "dataset/spam.csv",
    encoding='latin-1'
)

# Keep only needed columns
df = df[['v1', 'v2']]

# -----------------------------------
# CUSTOM MODERN PHISHING DATA
# -----------------------------------

custom_data = pd.DataFrame({

    'v1': [

        'spam',
        'spam',
        'spam',
        'spam',
        'spam',

        'spam',
        'spam',
        'spam',
        'spam',
        'spam',
        'spam',
        'spam',
        'spam',
        'spam',
        'spam',

        'ham',
        'ham',
        'ham',
        'ham',
        'ham'
    ],

    'v2': [

        'Your ATM card is blocked. Update KYC immediately.',
        'Your bank account has been suspended. Verify now.',
        'Click this link to claim your reward immediately.',
        'Urgent! Your account will be locked today.',
        'Verify your PAN card details now.',

        'Your Netflix payment failed. Re-enter card details now.',
        'Amazon alert: payment failed. Update billing information.',
        'Your WhatsApp account will be deleted unless verified.',
        'Your PayPal account is temporarily restricted.',
        'Apple ID locked due to suspicious login attempt.',
        'Google account compromised. Verify password immediately.',
        'Dear customer, your UPI access has been suspended.',
        'Your debit card has unusual activity. Confirm now.',
        'Final warning! Your account will be terminated today.',
        'You won a free iPhone. Claim reward immediately.',

        'Hey bro are we meeting tomorrow?',
        'Can you send me the notes?',
        'Lets go for lunch after class.',
        'Happy birthday have a great day.',
        'Assignment submission deadline is tomorrow.'
    ]
})

# Merge custom data
df = pd.concat([df, custom_data], ignore_index=True)

# -----------------------------------
# RENAME COLUMNS
# -----------------------------------

df.columns = ['label', 'message']

# -----------------------------------
# CONVERT LABELS
# -----------------------------------

df['label_num'] = df.label.map({
    'ham': 0,
    'spam': 1
})

# -----------------------------------
# TEXT PREPROCESSING
# -----------------------------------

df['clean_message'] = df['message'].apply(
    preprocess_text
)

# -----------------------------------
# TF-IDF VECTORIZATION
# -----------------------------------

tfidf = TfidfVectorizer(
    max_features=7000
)

X = tfidf.fit_transform(
    df['clean_message']
).toarray()

y = df['label_num']

# -----------------------------------
# TRAIN TEST SPLIT
# -----------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# -----------------------------------
# MODEL TRAINING
# -----------------------------------

model = MultinomialNB()

model.fit(X_train, y_train)

# -----------------------------------
# PREDICTIONS
# -----------------------------------

y_pred = model.predict(X_test)

# -----------------------------------
# ACCURACY
# -----------------------------------

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\n✅ Accuracy:", accuracy)

# -----------------------------------
# CLASSIFICATION REPORT
# -----------------------------------

print("\n📊 Classification Report:\n")

print(
    classification_report(
        y_test,
        y_pred
    )
)

# -----------------------------------
# CONFUSION MATRIX
# -----------------------------------

cm = confusion_matrix(
    y_test,
    y_pred
)

plt.figure(figsize=(6,4))

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.title("Confusion Matrix")

plt.xlabel("Predicted")

plt.ylabel("Actual")

plt.show()

# -----------------------------------
# SAVE MODEL
# -----------------------------------

joblib.dump(
    model,
    "phishing_model.pkl"
)

joblib.dump(
    tfidf,
    "tfidf_vectorizer.pkl"
)

print("\n✅ Model and vectorizer saved successfully!")